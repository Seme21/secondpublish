<?php
include("../inclued/header.php")
?>
    <div class="container-fluid">
        <!-- ================================FIRST SECTION ======================= -->
        <!-- ========================== Footer ===================== -->
        <div class="home">
            <!-- <h1>Home</h1> -->
            <div class="container home_container">
                <div class="homeBackground">
                    <img class="bgImg" src="../image/index/index.png" alt="Erorr 404: image not found ">
                    <div class="fgPra">
                        <h1>Printing Service <br>In Addis Ababa</h1>
                        <p>
                            Azael is a printing business that offers high-quality products and services.
                            We offer custom printing, design, and delivery, so you can get the perfect
                            product for any occasion. We use the latest technology to ensure the
                            highest quality prints and fast turnaround times. Get in touch today to
                            see how we can help you!
                        </p>
                    </div>
                    <p><a href="contactus.php" class="btn"><strong>Contact Us</strong></a> </p>
                </div>
            </div>
        </div>




        <!-- ================================END OF #FIRST SECTION ======================= -->

        <!-- ================================SECOND SECTION ======================= -->
        <div class="services">
            <h1>Services</h1>
            <div class="container services_container">
                <div class="serviceItem">
                    <article class="service" title="Label and Stiker">
                        <!-- <span class="category_icon"><i class="uil uil-bitcoin-circle"></i></span> -->
                        <a href="#"> <img src="../image/index/index2.png" alt=""></a>
                        <h1>Label And Sticker Printing</h1>
                        <p style="color: #0598c4f9 !important ;">A Service thatallows customers to request and print docmuments
                            online </p>
                    </article>

                    <article class="service" title="Branding Printing">
                        <!-- <span class="category_icon"><i class="uil uil-palette"></i></span> -->
                        <a href="#"> <img src="../image/index/index3.png" alt=""></a>
                        <h1>Branding Printing</h1>
                        <p style="color: #0598c4f9 !important ;">A Service that allows customers to order personalized documents
                            that help them to brand themseleves
                        </p>
                    </article>

                    <article class="service" title="Logo Designing">
                        <!-- <span class="category_icon"><i class="uil uil-usd-circle"></i></span> -->
                        <a href="#"> <img src="../image/index/index4.png" alt=""></a>
                        <h1>Logo Designing</h1>
                        <p style="color: #0598c4f9 !important ;">A Service that allows customers to have a custom made logos
                            with best graphics designers</p>
                    </article>
                </div>
            </div>
        </div>
        <!-- ================================END OF #SECOND SECTION ======================= -->

        <!-- ================================THIRD SECTION ======================= -->
        <div class="testimonials" title="Customer Testimonial">
            <!-- <h1>Testimonial</h1> -->
            <div class="container testimonials-container">
                <div class="testimonial">
                    <img class="imgT" src="../image/index/index5.png" alt="Thsi is picture five ***********">
                    <div class="testimonial_speach">
                        <p>
                            Azael in Addis Ababa has been an absolute dream to work with.
                            They have been incredibly helpful, quick and professional. I would highly 
                            recommend them for all your digital printing
                            needs.
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

                            - Girma Getachew
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <!-- ================================END OF #THIRD SECTION ======================= -->

        <!-- ================================FOURTH SECTION ======================= -->
        <div class="contactus" title="Contact Us Form">
            <!-- <h1>Contact Us </h1> -->
            <!-- <div class="contactus_right"> -->
            <div class="container content contactus_container">
                <div class="azaelPrint">
                    <h1>Azael Digital Printing Contact Form</h1>
                    <p>Fill Out This Form To Get In Touch With The Team At Azael Digital Printing For All Your Printing
                        Needs.
                    </p>
                </div>

                <div class="right-side">
                    <!-- <div class="topic-text">Send us a message</div>
                    <p>If you have any work from me or any types of quries related to my tutorial, you can send me message from
                        here. It's my pleasure to help you.</p> -->
                    <form method="post" name="contact_form" action="formValidation.php">
                        <div class="inputs">
                            <input type="text" name="name" placeholder="Name" title="Please filout your name here..">
                            <input type="email" name="email" placeholder="Email" title="Please filout your name here.."
                                title="Please filout your email here too..">
                        </div>
                        <div class="msg">
                            <textarea name="message" placeholder="Message" rows="7" cols="20"
                                title="Please leave your message here.."></textarea>
                        </div>
                        <div class="send">
                            <?php if (empty($msg)) { ?>
                            <!-- <form method="post" enctype="multipart/form-data"> -->
                            <input class="fileChoose" type="hidden" name="MAX_FILE_SIZE" value="100000">
                            <!-- Select one or more files -->
                            <input class="fileChoose" name="userfile[]" type="file" multiple="multiple"
                                title="If you want, attch your file/s here...">
                            <!-- <input class="fileChoose" type="submit" value="Send Files"> -->
                            <!-- </form> -->
                            <?php } else {
                                    echo htmlspecialchars($msg);
                                } ?>
                            <button type="submit" value="Submit" class="btn btn-primary" id="btn"
                                title="If you finished, just click send button."> Submit</button>
                        </div>
                    </form>

                </div>
            </div>
            <!-- </div> -->
        </div>
        <!-- ================================END OF #FOURTH SECTION ======================= -->

        <!-- ================================ FIVTH SECTION ======================= -->
        <div class="aboutus" title="About Us">

            <div class="about_container">
                <div class="container aboutus_container">

                    <img class="abtImg" src="../image/index/index6.png" alt="">
                    <div class="aboutus_htry">
                        <h1>About us</h1>
                        <p>
                            Hello everyone! I'm the founder of Azael, a digital printing business based here in the city. We
                            specialize in printing business cards, flyers, brochures, and other promotional materials. We
                            also offer customers to have a satisfactory experience
                            make sure your promotional materials look exactly the way you At Azael, we use the latest
                            technology and highest-quality materials to make
                            sure that all of our products stand out. We also take pride in providing excellent customer
                            service, so that you always have a positive experience
                            with us. We strive to make sure that your project comes out exactly how you envisioned it. So if
                            you're looking for a reliable printing service,
                            look no further than Azael!
                        </p>
                    </div>
                </div>
            </div>
        </div>
            <!-- ================================END OF #FIVTH SECTION ======================= -->
    </div>
        <?php
            include("../inclued/footer.php")
        ?>
 <!-- </div> -->
<!-- </div> -->