<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- web titile icon -->
    <link class="iconT" rel="icon" type="image/png" href="../image/logoicon.png" />
    <!-- a title for the website -->
    <title>Azeal Printing Service</title>
    <!-- link for iconscout CDN -->
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v2.1.6/css/unicons.css">
    <!-- link for google fonts (montserrat) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="">
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700;800;900&display=swap">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@100;200;300;400;500;700;800;900&display=swap"
        rel="stylesheet">
    <!-- link to a style -->
    <link rel="stylesheet" href="../dist/css/styleb.css">
    <!-- <link rel="stylesheet" href="../dist/css/style.css"> -->
    <!-- <script type="text/javascript" src="../dist/script/main.js"></script> -->
    <!-- link for swiper js -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css" />
    <!-- The images and text contents are fetched from the database and added to the slick slider.
    jQuery Library:
    The slick.js library has a dependency on jQuery, include the jQuery library file first.-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
    <!-- Slick Carousel Plugin:
    The jQuery slick plugin is used to add slider feature in HTML, so, include the CSS and JS library files of the slick slider. -->
    <!-- slick slider CSS library files -->
    <link rel="stylesheet" type="text/css" href="slick/slick.css" />
    <link rel="stylesheet" type="text/css" href="slick/slick-theme.css" />
    <!-- cdn link for bootstrapcdn to alter the menu bar -->
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" />

    <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.main.css' rel='stylesheet'>
    <!-- slick slider JS library file -->
    <script type="text/javascript" src="slick/slick.min.js"></script>
    <!-- Use the slick() method to initialize the slider and attach it to the HTML element. 
    Specify the parent div class (.product-slider) as a selector to bind the slick slider.
    You can use some setting options to configure the slider as per the application requirement. -->
    <script>
    $(document).ready(function() {
        $('.product-slider').slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            dots: false,
            infinite: true,
            arrows: true
        });
    });
    </script>


    <style>
    /* .sti_container {
        position: relative;
    }

    .btn {
        position: relative;
        display: inline-block;
        padding: 15px;
        background-color: blue;
        cursor: pointer;
        outline: none;
        border: 0;
        vertical-align: right;
        text-decoration: none;
        color: transparent;
        border-radius: 25px;
        -webkit-transition: width 0.5s;
        transition: width 0.5s;
        float: right;
    }

    .btn .btn-text {
        width: 0;
        display: inline-block;
        -webkit-transition: color 2s;
        transition: color 2s;
        vertical-align: top;
        white-space: nowrap;
        overflow: hidden;
        color: var(--color-topic);
    }

    .btn:hover .btn-text {
        width: 100vh;
        color: var(--color-white);
    } */
    </style>
</head>

<body>
    <!-- <section class="fluid-container"> -->
    <div class="container-fluid">
        <nav>
            <!-- <section class="fluid-container"> -->
            <div class="container nav_container">
                <a href="index.php">
                    <h4>Azael Printing</h4>
                </a>
                <ul class="nav_menu">
                    <li><a href="index.php"><i class="uil uil-home">Home</i> </a></li>
                    <li><a href="about.php"><i class="uil uil-books">About</i> </a></li>
                    <li><a href="service.php"><i class="uil uil-file-share-alt">Service</i> </a></li>
                    <li><a href="contact.php"><i class="uil uil-comments">ContactUs</i> </a></li>
                    <!-- <div class="auth">
                    <li><a href="index.php">Login</a></li>
                    <li><a href="index.php">Signup</a></li>                    
                </div> -->

                </ul>
                <!-- <div class="searchbox">
                    <input class="qodef-search-opener-text"> <a href=""><i class="uil uil-search" aria-placeholder="Please search here...">Search</i></a></input>
            </div> -->
                <!-- <img src="../image/logo.png" alt="image not found" class="logo"> -->
                <button id="open-menu-btn" title="click on to open Menu"><i class="uil uil-bars"></i> </button>
                <button id="close-menu-btn" title="click on to close Menu"><i class="uil uil-multiply"></i> </button>
            </div>
        </nav>
    </div>
        <!-- <nav>

        <div class="sti_container">
            <button class="btn btn-primary">
                <span class="btn-icon"><i class="fa fa-shopping-bag" aria-hidden="true"></i></span>
                <span class="btn-text">
                    <div class="container nav_container">
                        <a href="index.php">
                            <h4>Azael Printing</h4>
                        </a>
                        <ul class="menu_bar">
                            <li><a href="index.php"><i class="uil uil-home">Home</i> </a></li>
                            <li><a href="about.php"><i class="uil uil-books">About</i> </a></li>
                            <li><a href="service.php"><i class="uil uil-file-share-alt">Service</i> </a></li>
                            <li><a href="contact.php"><i class="uil uil-comments">ContactUs</i> </a></li>
                        </ul>
                    </div>
                </span>
            </button>
        </div>
    </nav> -->