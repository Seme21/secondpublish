        <!-- ========================== Footer ===================== -->
        <div class="container-fluid">
            <footer class="footer">
                <div class="container footer_container">
                    <div class="footer_1">
                        <ul class="footer_socialmds">
                            <li><a href="#" target="_blank"><i class="uil uil-whatsapp"></i> </a> </li>
                            <li><a href="#" target="_blank"><i class="uil uil-facebook-f"></i> </a> </li>
                            <li><a href="#" target="_blank"><i class="uil uil-instagram-alt"></i></a></li>
                            <li><a href="#" target="_blank"><i class="uil uil-linkedin"></i> </a> </li>
                            <li><a href="#" target="_blank"><i class="uil uil-telegram-alt"></i> </a> </li>
                            <li><a href="#" target="_blank"><i class="uil uil-tiktok-alt"></i> </a> </li>
                            <li><a href="#" target="_blank"><i class="uil uil-twitter-alt"></i> </a> </li>
                        </ul> <br>
                        <p>@azaelpplc.print</p>
                    </div>

                    <div class="footer_2">
                        <h4>CONTACT US </h4>
                        <div class="address">
                            <p><i class="uil uil-phone-volume">09-41-41-31-32</i> &nbsp;&nbsp;&nbsp; <i
                                    class="uil uil-phone-volume">07-03-79-24-47</i></p>
                            <p><i class="uil uil-location-point"> Remet Tabor Oda Building, Piassa,</i>
                            <h2>Addis Ababa,
                                Ethiopia.</h2>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="footer_copyright">
                    <small>Copy right &copy; AZAEL PRINTING protected under law! <a href="https://t.me/Yotod776"
                            target="_blank">Develope by
                            Semahegn Tilahun D.</a> </small>
                </div>
            </footer>

            <!-- ========================== end of Footer ===================== -->
            <script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>
            <script src="../dist/script/main.js"></script>
            <script>
            var swiper = new Swiper(".mySwiper", {
                slidesPerView: 1,
                spaceBetween: 30,
                pagination: {
                    el: ".swiper-pagination",
                    clickable: true,
                },
                // change while width is >=600px
                breakpoints: {
                    600: {
                        slidesPerView: 2
                    }
                }
            });
            </script>
            <!-- </section> -->
        </div>
    </body>
</html>