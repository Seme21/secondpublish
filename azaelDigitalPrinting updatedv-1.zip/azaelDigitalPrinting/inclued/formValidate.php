<!DOCTYPE HTML>
<html>

<head>
    <style>
    .error {
        color: #FF0000;
    }
    </style>
</head>
        <!-- =======================  php code for form validation  ========================== -->
        <?php
            // define variables and set to empty values
            $nameErr = $nameErr = $emailErr = $genderErr = $websiteErr = "";
            $name = $email = $gender = $comment = $website = "";

            if ($_SERVER["REQUEST_METHOD"] == "POST") {
            if (empty($_POST["name"])) {
                $nameErr = "First Name is required";
            } else {
                $name = test_input($_POST["firstName"]);
                // check if name only contains letters and whitespace
                if (!preg_match("/^[a-zA-Z- -' ]*$/",$name)) {
                $nameErr = "Only letters are allowed";
                }
            }

            if (empty($_POST["lastName"])) {
                $nameErr = "Last Name is required";
            } else {
                $name = test_input($_POST["lastName"]);
                // check if name only contains letters and whitespace
                if (!preg_match("/^[a-zA-Z- -' ]*$/",$name)) {
                $nameErr = "Only letters are allowed";
                }
            }            
            
            if (empty($_POST["email"])) {
                $emailErr = "Email is required";
            } else {
                $email = test_input($_POST["email"]);
                // check if e-mail address is well-formed
                if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $emailErr = "Invalid email format";
                }
            }
                
            if (empty($_POST["website"])) {
                $website = "";
            } else {
                $website = test_input($_POST["website"]);
                // check if URL address syntax is valid (this regular expression also allows dashes in the URL)
                if (!preg_match("/\b(?:(?:https?|ftp):\/\/|www\.)[-a-z0-9+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/i",$website)) {
                $websiteErr = "Invalid URL";
                }
            }

            if (empty($_POST["comment"])) {
                $comment = "";
            } else {
                $comment = test_input($_POST["comment"]);
            }

            if (empty($_POST["gender"])) {
                $genderErr = "Gender is required";
            } else {
                $gender = test_input($_POST["gender"]);
            }
            }

            function test_input($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
            }
        ?>
<body>



<!-- ======================== -->

<?php
include("../inclued/eheader.php");
include("../inclued/formValidate.php");
?>

<style>
.error {
    color: #FF0000 !important;
}
</style>


<section class="contact">
    <div class="container contact_container">
        <aside class="contact_aside">
            <div class="aside_image">
                <img src="../image/contact/contactUs.png" alt="not found">
            </div>
            <h2>Contact Us</h2>
            <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Architecto sunt aut earum quasi ab odit fuga
                assumenda rem iure reprehenderit obcaecati, eaque repellat sed et. </p>
            <ul class="contact_details">
                <li>
                    <i class="uil uil-phone-times"></i>
                    <h5>+251941413132</h5>
                </li>
                <li>
                    <i class="uil uil-envelop"></i>
                    <h5>info@azaelprinting.com</h5>
                </li>
                <li>
                    <i class="uil uil-location-point"></i>
                    <h5>Addis Ababa, Ethiopia</h5>
                </li>
            </ul>
            <ul class="contact_socialmds">
                <li> <a href="https://facebook.com"> <i class="uil uil-facebook-f"></i> </a> </li>
                <li> <a href="https://instagram.com"> <i class="uil uil-instagram"></i> </a> </li>
                <li> <a href="https://twitter.com"> <i class="uil uil-twitter"></i> </a> </li>
                <li> <a href="https://linkedin.com"> <i class="uil uil-linkedin-alt"></i> </a> </li>
            </ul>
        </aside>

        <p><span class="error">* required field</span></p>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" class="contact_form">

            <div class="form_name">
                <input type="text" name="firstName" placeholder="Type Your First Name" value="<?php echo $name;?>">
                <h6 class="error">* <?php echo $nameErr;?></h6>
                <input type="text" name="lastName" placeholder="Type Your Last Name" value="<?php echo $name;?>">
                <h6 class="error">* <?php echo $nameErr;?></h6>
            </div>
            <input type="email" name="Email Address" placeholder="Please Type Your Email Address Here ..."
                value="<?php echo $email;?>">
            <h6 class="error">* <?php echo $emailErr;?></h6>
            <textarea name="Message" id="" cols="30" rows="10" placeholder="Please Type Your Message Here ..."
                required><?php echo $comment;?></textarea>
            <button type="submit" class="btn btn-primary">Send Message</button>
            <div class="form_name">
                Please Select Your Gender:
                <input type="radio" name="gender" <?php if (isset($gender) && $gender=="female") echo "checked";?>
                    value="female">Female
                <input type="radio" name="gender" <?php if (isset($gender) && $gender=="male") echo "checked";?>
                    value="male">Male
                <input type="radio" name="gender" <?php if (isset($gender) && $gender=="other") echo "checked";?>
                    value="other">Other
                <h6 class="error">* <?php echo $genderErr;?></h6>
            </div>
        </form>
    </div>
</section>

<?php
include("../inclued/efooter.php");
?>

<!-- ============================================ -->