<?php

$name = $_POST["name"];
$email = $_POST["email"];
$subject = $_POST["subject"];
$message = $_POST["message"];

require "/xampp/htdocs/My_project/PHP/azaelDigitalPrinting/inclued/PHPMailer/vendor/autoload.php";

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;

$mail = new PHPMailer(true);

// $mail->SMTPDebug = SMTP::DEBUG_SERVER;

$mail->isSMTP();
$mail->SMTPAuth = true;

$mail->Host = "smtp.example.com";
$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
$mail->Port = 587;

$mail->Username = "yegnabetsew@gmail.co.com";
$mail->Password = "password";

$mail->setFrom($email, $name);
$mail->addAddress("yegnabetsew@gmail.com", "Dave");

$mail->Subject = $subject;
$mail->Body = $message;

$mail->send();

header("Location: sent.html");




?>

// ==============================

<?php

include '../auth/dbconnection.php';
require ('../phpmailer/PHPMailerAutoload.php');
$mail = new PHPMailer(TRUE);

 //Server settings
 $mail->isSMTP();                             // Set mailer to use SMTP
 $mail->Host       = 'localhost';             // Set the SMTP server to send through
 $mail->SMTPAuth   = true;                    // Enable SMTP authentication
 $mail->SMTPDebug = 4; 
 $mail->Username   = 'seushms@gmail.com';     // SMTP false username
 $mail->Password   = '';                      // SMTP false password
 $mail->SMTPSecure = 'tsl';         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
 $mail->Port       = 587;                // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above

 
 $stmt1 = $conn->prepare("SELECT * FROM patients WHERE p_id=?");
 $stmt1->bind_param("s", $_POST['p_id']);
 $stmt1->execute();
 $result = $stmt1->get_result();
  if(mysqli_num_rows($result)>0){
    while($row = $result->fetch_assoc()) {
     $username=$row['username'];
     $email=$row['email'];
     
       //Recipients
   $mail->setFrom('seus@gmail.com', 'Mailer');
   $mail->addAddress($email);     // Add a recipient
   $mail->addReplyTo('seus@gmail.com');

    }
}

if (isset($_POST['data_id'])) {

  $id=$_POST['data_id'];
  $date=$_POST['date'];

   $stmt = $conn->prepare("UPDATE appointment SET admin_status = ?,patient_status = ? WHERE apt_id= ?");
   $admin_status='1';
   $patient_status='1';

   $stmt->bind_param("ssi", $admin_status,$patient_status, $id);
   $status = $stmt->execute();

   if ($status === true) {

    // Content
    $mail->isHTML(true);     // Set email format to HTML
    $mail->Subject = "Regarding the Appointment Request";
    $mail->Body    = "<h3 align=right> Your Appointment requested on'.$date. 'has <b> approved.</b> <br> Please refer the patient schedule for time arrivals. <br> Best Regards from </b> <b><i>  SEUS Hospitals </i> </b>";

    $mail->AltBody = "This is the body in plain text for non-HTML mail clients";
    $mail->send();

    echo "Records was updated successfully."; 

} else {
    echo 'cant'; 
}

$conn->close(); 
}
?>